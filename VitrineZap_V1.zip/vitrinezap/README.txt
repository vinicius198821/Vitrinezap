VITRINEZAP — V1
================
Esta é uma versão inicial estática, responsiva e pronta para demonstração.

COMO TESTAR:
1. Extraia o ZIP.
2. Abra frontend/index.html no navegador.
3. O painel administrativo está em admin/index.html.

IMPORTANTE:
- Os links dos produtos estão como "#".
- Substitua-os pelos seus links de afiliado/parceiro.
- Esta V1 não processa pagamentos nem pedidos; a compra acontece no parceiro.

PRÓXIMA EVOLUÇÃO:
- Backend + banco de dados
- Login de administrador
- Cadastro/edição de produtos
- Importação de catálogo
- Links de afiliado por parceiro
- Rastreamento de cliques
- Comparação automática de preços
- SEO e domínio próprio
