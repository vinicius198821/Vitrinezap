const produtos=[
{id:1,nome:"Fone Bluetooth Pro",cat:"Eletrônicos",emoji:"🎧",preco:"R$ 59,90",parceiro:"Shopee",link:"#"},
{id:2,nome:"Smartwatch Fitness",cat:"Eletrônicos",emoji:"⌚",preco:"R$ 89,90",parceiro:"Mercado Livre",link:"#"},
{id:3,nome:"Kit Organizador para Casa",cat:"Casa",emoji:"🧺",preco:"R$ 39,90",parceiro:"Havan",link:"#"},
{id:4,nome:"Mochila Casual",cat:"Moda",emoji:"🎒",preco:"R$ 69,90",parceiro:"Shopee",link:"#"},
{id:5,nome:"Luminária LED",cat:"Casa",emoji:"💡",preco:"R$ 29,90",parceiro:"Mercado Livre",link:"#"},
{id:6,nome:"Teclado Gamer",cat:"Games",emoji:"⌨️",preco:"R$ 119,90",parceiro:"Shopee",link:"#"},
{id:7,nome:"Caixa de Ferramentas",cat:"Ferramentas",emoji:"🧰",preco:"R$ 149,90",parceiro:"Havan",link:"#"},
{id:8,nome:"Kit Beleza",cat:"Beleza",emoji:"💄",preco:"R$ 49,90",parceiro:"Mercado Livre",link:"#"}
];
const cats=["Todos","Eletrônicos","Casa","Moda","Beleza","Ferramentas","Games"];
let atual=produtos;
function render(list=atual){document.querySelector("#products").innerHTML=list.map(p=>`<article class="card"><div class="pic">${p.emoji}</div><span class="tag">${p.parceiro}</span><h3>${p.nome}</h3><div class="partner">${p.cat}</div><div class="price">${p.preco}</div><a class="buy" href="${p.link}" onclick="registrarClique(${p.id})">Ver oferta</a></article>`).join("")}
function renderCats(){document.querySelector("#cats").innerHTML=cats.map(c=>`<button class="cat" onclick="filtrar('${c}')">${c}</button>`).join("")}
function filtrar(c){atual=c==="Todos"?produtos:produtos.filter(p=>p.cat===c);render(atual)}
function buscar(){const q=document.querySelector("#search").value.toLowerCase();atual=produtos.filter(p=>(p.nome+" "+p.cat+" "+p.parceiro).toLowerCase().includes(q));render(atual)}
function mostrarTodos(){event.preventDefault();atual=produtos;render()}
function registrarClique(id){console.log("Clique no produto",id)}
renderCats();render();